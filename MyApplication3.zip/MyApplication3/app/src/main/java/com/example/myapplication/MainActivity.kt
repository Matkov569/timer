package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.view.View
import android.widget.Button
import android.widget.TextView
import org.w3c.dom.Text
import java.util.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.b00).setOnClickListener{time(600)};
        findViewById<Button>(R.id.b10).setOnClickListener{time(60)};
        findViewById<Button>(R.id.b20).setOnClickListener{time(10)};
        findViewById<Button>(R.id.b30).setOnClickListener{time(1)};

        findViewById<Button>(R.id.b01).setOnClickListener{time(-600)};
        findViewById<Button>(R.id.b11).setOnClickListener{time(-60)};
        findViewById<Button>(R.id.b21).setOnClickListener{time(-10)};
        findViewById<Button>(R.id.b31).setOnClickListener{time(-1)};

        findViewById<Button>(R.id.Start).setOnClickListener{timeStart()};
        findViewById<Button>(R.id.Pause).setOnClickListener{timePause()};
        findViewById<Button>(R.id.Stop).setOnClickListener{timeStop()};

    }

    var timeCounter = 0;

    fun time(time:Int){
        timeCounter += time;
        if(timeCounter>3599) timeCounter=3599;
        else if(timeCounter<0) timeCounter=0;

        refresh();

        if (timer != null){
            timer!!.cancel();
            createTimer();
            if(isRunning){
                timer!!.start()
            }
        }


    }

    private fun refresh(){
        var m10:TextView = findViewById<TextView>(R.id.t0);
        var m1:TextView = findViewById<TextView>(R.id.t1);
        var s10:TextView = findViewById<TextView>(R.id.t2);
        var s1:TextView = findViewById<TextView>(R.id.t3);

        m10.text=((timeCounter/600)%6).toString();
        m1.text=((timeCounter/60)%10).toString();
        s10.text=((timeCounter/10)%6).toString();
        s1.text=(timeCounter%10).toString();
    }

    private var timer: CountDownTimer? = null;
    private var isRunning = false;

    private fun createTimer(){
        timer = object : CountDownTimer( (timeCounter*1000).toLong(),1000){
            override fun onTick(millisUntilFinished: Long) {
                timeCounter = (millisUntilFinished/1000).toInt();
                refresh();
            }

            override fun onFinish() {
                this.cancel();
            }
        }
    }

    private fun timeStart(){
        createTimer();
        isRunning=true;
        timer!!.start();
    }
    private fun timePause(){
        isRunning = false;
        timer!!.cancel();
    }
    private fun timeStop(){
        isRunning = false;
        timer!!.cancel();
        time(-100000);
        timer = null;
    }
}